package com.ust.herokuapp.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.herokuapp.base.ReusableFunctions;

public class AddorRemove {
	WebDriver driver;
    ReusableFunctions rf;
    
    public AddorRemove(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunctions(driver);
 
	}
    
    
    @FindBy(css="#content > div > button")
    public WebElement addelements;
    
    @FindBy(id="elements")
    public WebElement delete;
    
    //to add elements
    public void addelementclick() {
    	addelements.click();
    	
    }
    
    //to remove elements
    public void deleteelementclick() {
    	delete.click();
    	
    }
    
    //To check current url
    public boolean checkUrl(String property) {
		return rf.checkurl(property);
	}
	

}

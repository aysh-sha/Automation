package com.ust.herokuapp.base;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReusableFunctions {
	WebDriver driver;
	
	public ReusableFunctions(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
 
	}
	
	public void clickElement(WebElement element) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(d->element.isDisplayed());
		element.click();
	}
	public boolean containsText(String txt,WebElement element) {
		return element.getText().contains(txt);
	}
	public boolean checkurl(String url) {
		if ((driver.getCurrentUrl()).equals(url)) {
			return true;
		} else {
			return false;
		}
	}
	public boolean isPresent(WebElement element) {
		if (element.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}
	public void insertText(String text, WebElement element) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		element.clear();
		element.sendKeys(text);
	}
	public void waits() {
		  try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
	  
	  public void selectDropdown(WebElement element,String txt) {
			Select obj = new Select(element);
			obj.selectByVisibleText(txt);
			
		}
	}
		
	
	       
	
		



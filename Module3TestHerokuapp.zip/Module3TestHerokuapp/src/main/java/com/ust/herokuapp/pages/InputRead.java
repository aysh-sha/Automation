package com.ust.herokuapp.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.herokuapp.base.ReusableFunctions;

public class InputRead {
	WebDriver driver;
    ReusableFunctions rf;
    
    public InputRead(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunctions(driver);
 
	}
    
    
    @FindBy(xpath="//div[@id=\"content\"]//div/input")
    public WebElement inputs;
    
    public void clickBtn(WebElement el) {
		rf.clickElement(el);
	}
    
public void clickinput() throws InterruptedException {
		
		inputs.click();
	}

}

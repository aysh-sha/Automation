package com.ust.herokuapp.utils;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	
	public static String[][] excel(String excelPath,String sheetname) throws IOException{
		
		
			FileInputStream  fis= new FileInputStream(excelPath);
		
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet(sheetname);
		//To get total no of rows
		int rowcount= sheet.getPhysicalNumberOfRows();
		int colcount = sheet.getRow(0).getPhysicalNumberOfCells();
		
		String[][] data = new String[rowcount][colcount];
		DataFormatter df = new DataFormatter();
		for (int i=0;i<rowcount; i++) {
			for(int j =0;j<colcount;j++) {
				data[i][j]= df.formatCellValue(sheet.getRow(i).getCell(j));
			}
		}
		
		
		return data;
		
	}

}

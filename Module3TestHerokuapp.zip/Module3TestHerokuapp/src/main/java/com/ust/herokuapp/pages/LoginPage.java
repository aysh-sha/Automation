package com.ust.herokuapp.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.herokuapp.base.ReusableFunctions;

public class LoginPage {
	WebDriver driver;
	ReusableFunctions rf;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunctions(driver);
 
	}
	
	@FindBy(id="username")
	public WebElement username;
	
	@FindBy(id="password")
	public WebElement password;
	
	@FindBy(xpath="//div/form/button/i")
	public WebElement LoginBtn;
	
	@FindBy(id="flash")
	public WebElement errormsg;
	
	
	public void insertText(WebElement el,String txt) {
		rf.insertText(txt, el);
	
	}
	public void clickBtn(WebElement el) {
		rf.clickElement(el);
	}
	
	public boolean isPresent(WebElement el) {
		return rf.isPresent(el);
	}
	
	//clicking the login button
	public void clickLogInButton() throws InterruptedException {
		
		LoginBtn.click();
	}
	
	//to get the error message
	public String errormsg() {
		return errormsg.getText();
	}
	
	public void waitUntil(WebElement element) {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(d->element.isDisplayed());
			
		}
	public String getErrorMsg() {
		return errormsg.getText();
	}


}

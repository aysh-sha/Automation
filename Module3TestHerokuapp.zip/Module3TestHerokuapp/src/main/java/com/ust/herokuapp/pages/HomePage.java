package com.ust.herokuapp.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import com.ust.herokuapp.base.ReusableFunctions;

public class HomePage {
	WebDriver driver;
    ReusableFunctions rf;
    LoginPage lp;
    
    public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunctions(driver);
 
	}
    
    @FindBy(linkText="Add/Remove Elements")
    public WebElement addorremelement;
    
    @FindBy(linkText="Checkboxes")
    public WebElement checkbox;
    
    @FindBy(linkText="Form Authentication")
    public WebElement formauthentication;
    
    @FindBy(linkText="Inputs")
    public WebElement inputs;
    
    
    
    
    public AddorRemove clickElement(WebElement el) {
    	rf.clickElement(el);
    	return new AddorRemove(driver);
    }
    
    public CheckBox clickcheckbox(WebElement el) {
    	rf.clickElement(el);
    	return new CheckBox(driver);
    }
    
    public LoginPage clickformauthentication(WebElement el) {
    	rf.clickElement(el);
    	return new LoginPage(driver);
    }
    
    public boolean checkUrl(String property) {
		return rf.checkurl(property);
	}
	
    public LoginPage clickLogin(WebElement el) {
		rf.clickElement(el);
		return new LoginPage(driver);
	}
    
    public InputRead clickInputs(WebElement el) {
		rf.clickElement(el);
		return new InputRead(driver);
	}

}

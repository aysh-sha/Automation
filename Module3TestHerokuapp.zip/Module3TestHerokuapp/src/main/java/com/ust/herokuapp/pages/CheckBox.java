package com.ust.herokuapp.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.herokuapp.base.ReusableFunctions;

public class CheckBox {
	
	WebDriver driver;
    ReusableFunctions rf;
    
    public CheckBox(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunctions(driver);
 
	}
   

	@FindBy(css="input[type=checkbox]:nth-child(1)")
    public WebElement checkbox1;
    
    @FindBy(css="input[type=checkbox]:nth-child(3)")
    public WebElement checkbox2;
    
    public void checkboxclick() {
    	checkbox1.click();
    	
    }
    
    public void checkboxclick2() {
    	checkbox2.click();
    	
    }
    
    
	

}

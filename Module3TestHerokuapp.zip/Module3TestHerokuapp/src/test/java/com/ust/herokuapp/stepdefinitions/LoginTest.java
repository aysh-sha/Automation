package com.ust.herokuapp.stepdefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.ust.herokuapp.pages.HomePage;
import com.ust.herokuapp.pages.LoginPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginTest {
	WebDriver driver = Hooks.driver;
	Properties prop = Hooks.prop;
	HomePage hp;
	LoginPage lp;
	
	
	

	@Given("The user in Herokuapp page")
	public void the_user_in_herokuapp_page() {
		hp = new HomePage(driver);
		driver.get(prop.getProperty("baseurl"));
		lp = hp.clickformauthentication(hp.formauthentication);
		
		
	}
    
	@When("the invalid username is entered")
	public void the_invalid_username_is_entered() {
		lp=new LoginPage(driver);
		lp.insertText(lp.username,prop.getProperty("invalidusername"));
	    }
	@When("the invalid password is entered")
	public void the_invalid_password_is_entered() {
		
		lp.insertText(lp.password,prop.getProperty("invalidusername"));
	    
	}
	@When("the login button is clicked")
	public void the_login_button_is_clicked() throws InterruptedException {
		lp.clickLogInButton();
	    
	}
	@Then("an alert message should be displayed")
	public void an_alert_message_should_be_displayed() {
		String errormsg = lp.getErrorMsg();
		  assertTrue(errormsg.contains("Your username is invalid!"));
	    
	}
		
		
		
		
	
}

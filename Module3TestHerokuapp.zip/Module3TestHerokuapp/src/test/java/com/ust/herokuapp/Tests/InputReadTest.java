package com.ust.herokuapp.Tests;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ust.herokuapp.base.ReusableFunctions;
import com.ust.herokuapp.base.SetUp;
import com.ust.herokuapp.pages.AddorRemove;
import com.ust.herokuapp.pages.HomePage;
import com.ust.herokuapp.pages.InputRead;
import com.ust.herokuapp.utils.ExcelReader;

public class InputReadTest extends SetUp{
	WebDriver driver;
	HomePage hp;
	AddorRemove ar;
	ReusableFunctions rf;
	InputRead ir;

	
	@BeforeTest
	public void setup() {
		driver = invokeBrowser();
		driver.get(prop.getProperty("baseurl"));
		hp = new HomePage(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	
	
	@Test(priority = 0)
	public void loadPage() {
		
		hp = new HomePage(driver);
		assertTrue(hp.checkUrl(prop.getProperty("baseurl")), "Failed to load base url");
	}

	@Test(priority = 1)
	public void addelement() {
	    ir=hp.clickInputs(hp.inputs);
		ir = new InputRead(driver);
	}
	
		
	  
	@Test(priority = 2 ,dataProvider = "input")
	public void sign_up_with_data(String number) throws InterruptedException {
			//ir.enterText(ir.inputs);
	}
	
	//To read data from excel
	 @DataProvider
	  public String[][] input() throws IOException {
		  
	   String path = System.getProperty("user.dir") + "\\DataSource\\Dataexcel.xlsx";
	   String Sheetname= "Sheet1";
	   String [][] data= ExcelReader.excel(path,Sheetname);
	 
	   return data;
	   
	  }
}

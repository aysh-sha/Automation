package com.ust.herokuapp.Tests;

import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.herokuapp.base.ReusableFunctions;
import com.ust.herokuapp.base.SetUp;
import com.ust.herokuapp.pages.AddorRemove;
import com.ust.herokuapp.pages.HomePage;
import com.ust.herokuapp.utils.ExtentReportListeners;

@Listeners(ExtentReportListeners.class)
public class AddorRemoveTest extends SetUp{
	WebDriver driver;
	HomePage hp;
	AddorRemove ar;
	ReusableFunctions rf;

	
	@BeforeTest
	public void setup() {
		driver = invokeBrowser();
		driver.get(prop.getProperty("baseurl"));
		hp = new HomePage(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	
	
	@Test(priority = 0)
	public void loadPage() {
		
		hp = new HomePage(driver);
		assertTrue(hp.checkUrl(prop.getProperty("baseurl")), "Failed to load base url");
	}

	@Test(priority = 1)
	public void addelement() {
	    ar=hp.clickElement(hp.addorremelement);
		ar = new AddorRemove(driver);
		ar.addelementclick();
		ar.deleteelementclick();
	  
  }
}

package com.ust.herokuapp.Tests;

import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ust.herokuapp.base.ReusableFunctions;
import com.ust.herokuapp.base.SetUp;
import com.ust.herokuapp.pages.AddorRemove;
import com.ust.herokuapp.pages.CheckBox;
import com.ust.herokuapp.pages.HomePage;

public class CheckboxTest extends SetUp {
	WebDriver driver;
	HomePage hp;
	AddorRemove ar;
	CheckBox cb;
	ReusableFunctions rf;

	
	@BeforeTest
	public void setup() {
		driver = invokeBrowser();
		driver.get(prop.getProperty("baseurl"));
		hp = new HomePage(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	
	
	@Test(priority = 0)
	public void loadPage() {
		
		hp = new HomePage(driver);
		assertTrue(hp.checkUrl(prop.getProperty("baseurl")), "Failed to load base url");
	}

	@Test(priority = 1)
	public void VerifyCheckboxclick() {
		cb=hp.clickcheckbox(hp.checkbox);
		cb = new CheckBox(driver);
		cb.checkboxclick();
	
		cb.checkboxclick2();
		
		
	  
  }
}



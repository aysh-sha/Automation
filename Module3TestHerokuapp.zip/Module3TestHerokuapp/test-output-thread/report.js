$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"c882f852-68bf-4a20-8e4b-592915ed9c32","feature":"Herokuapp Invalid Login Authentication","scenario":"Test Login functionality with invalid credentials.","start":1717069466227,"group":1,"content":"","tags":"@invalid,","end":1717069478640,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});
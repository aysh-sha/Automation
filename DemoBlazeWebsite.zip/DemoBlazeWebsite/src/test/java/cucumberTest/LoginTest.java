package cucumberTest;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;

import org.testng.annotations.DataProvider;

import com.ust.demoblaze.pages.AddToCart;
import com.ust.demoblaze.pages.LoginPage;
import com.ust.demoblaze.utils.ExcelReader;
import com.ust.demoblaze.utils.ObjectReader;

import baseUI.SetUp;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginTest extends SetUp {
	LoginPage lp;
	AddToCart ac;
	
	
	
	@Before
	public void setup() throws IOException, InterruptedException
	{  
		prop = ObjectReader.initProperties();
		driver = invokeBrowser();
		driver.get(prop.getProperty("baseurl"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		

		
	}
	@After
	public void teardown() throws InterruptedException {
		Thread.sleep(2000);
	    driver.quit();
}
	
	@DataProvider(name="dp")
	  public String[][] dp() throws IOException {
		  
	   String path = System.getProperty("user.dir") + "\\DataSource\\Dataexcel.xlsx";
	   String Sheetname= "Sheet1";
	   String [][] data= ExcelReader.excel(path,Sheetname);
	 
	   return data;
	   
	  }
	
	
	
	@Given("the user in the DemoBlaze Login page")
	public void the_user_in_the_demo_blaze_login_page() {
		lp = new LoginPage(driver);
		driver.get(prop.getProperty("baseurl"));
		lp.Login();
	}
	
	@When("the invalid username is entered")
	public void the_invalid_username_is_entered() {
		lp.enterusername(prop.getProperty("invalidusername"));
	}
	
	@And("the invalid password is entered")
	public void the_invalid_password_is_entered() {
		
		lp.enterpassword(prop.getProperty("password"));


	    
	}
	
	@Then("an alert message should be displayed")
	public void an_alert_message_should_be_displayed() {
		String alertText= driver.switchTo().alert().getText();
		assertTrue(alertText.contains(prop.getProperty("alertTextLogin")),"Error Message Not Found");
	    
	}
	
	@When("the valid username is entered")
	public void the_valid_username_is_entered() {
		lp = new LoginPage(driver);
		 lp.enterusername(prop.getProperty("username"));

	}
	
	@When("the valid password is entered")
	public void the_valid_password_is_entered() {
		lp = new LoginPage(driver);
		lp.enterpassword(prop.getProperty("password"));

	}
	
	@When("the login button is clicked")
	public void the_login_button_is_clicked() {
		ac = lp.clicklogin();
	    
	}
	
	@Then("the products page should be displayed")
	public void the_products_page_should_be_displayed() {
		String actURL = ac.getCurrentURL();
		  assertTrue(actURL.contains("cart"));
	}
}


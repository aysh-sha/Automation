package cucumberTest;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(
			features = {"C:\\Users\\271559\\Desktop\\Java\\DemoBlazeWebsite\\src\\test\\java\\cucumberTest"},
			glue = {"cucumberTest"}
			//plugin = {"me.jvt.cucumber.report.PrettyReports:Reports"}
			  )
			
	//publish = true
			//plugin = {"me.jvt.cucumber.report.PrettyReports:Reports"}
			//dryRun = true
			
	public class CucumberRunner extends AbstractTestNGCucumberTests{
	
}

package com.ust.demoblaze;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.demoblaze.pages.LoginPage;
import com.ust.demoblaze.pages.SignUp;
import com.ust.demoblaze.utils.ExcelReader;
import com.ust.demoblaze.utils.ExtentReportListeners;

import baseUI.ReusableFunctions;
import baseUI.SetUp;
@Listeners(ExtentReportListeners.class)
public class SignUpTest  extends SetUp{
	SignUp su;
	LoginPage lp;
	ReusableFunctions rf;
	
	@BeforeTest
	public void setup() {
		driver = invokeBrowser();
		driver.get(prop.getProperty("baseurl"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	

	  @DataProvider
	  public String[][] dp() throws IOException {
		  
	   String path = System.getProperty("user.dir") + "\\DataSource\\Dataexcel.xlsx";
	   String Sheetname= "Sheet1";
	   String [][] data= ExcelReader.excel(path,Sheetname);
	 
	   return data;
	   
	  }



	@Test(priority = 0)
	public void loadPage() {
		
		su = new SignUp(driver);
		assertTrue(su.checkUrl(prop.getProperty("baseurl")), "Failed to load base url");
	}

	@Test(priority = 1)
	public void clickSignUp() throws InterruptedException {
		su = new SignUp(driver);
		su.SignUp();
		Thread.sleep(2000);
		
		su.clickSignUp();
		
		wait();
		String alertText= driver.switchTo().alert().getText();
		assertTrue(alertText.contains(prop.getProperty("alertTextSignUp")),"Error Message Not Found");
		//assertTrue(su.isPresent(su.clickSignUp()), "Login with null data case failed");
		Thread.sleep(2000);
	}
	@Test(priority = 1 ,dataProvider = "dp")
	public void enterCredentials(String username,String password) throws InterruptedException {
		su = new SignUp(driver);
		su.SignUp();
		su.enterusername(username);
		su.enterpassword(password);
		lp= su.clickSignUp();
		
		
	
	}
	
}
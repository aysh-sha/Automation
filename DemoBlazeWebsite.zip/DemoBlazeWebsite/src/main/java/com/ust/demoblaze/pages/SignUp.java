package com.ust.demoblaze.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseUI.ReusableFunctions;



public class SignUp {
	WebDriver driver;
	LoginPage lp;
	ReusableFunctions rf;
	
		
		public SignUp(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
			rf= new ReusableFunctions(driver);
		}
		
		
		@FindBy(linkText= "Sign up")
		public WebElement signup;
		
		@FindBy(id = "sign-username")
		public WebElement username;
		
		@FindBy(id = "sign-password")
		public WebElement password;
		
		
		@FindBy(id="signInResultMessage")
		public WebElement errormsg;
		
		@FindBy(xpath="//*[@id=\"signInModal\"]/div/div/div[3]/button[2]")
		private WebElement signupbtn;
		
		
		
		public void SignUp() {
			signup.click();
			
		}
		
		public void enterusername(String utext) {
			username.sendKeys(utext);
		}
		public void enterpassword(String ptext) {
			password.sendKeys(ptext);
		}
		
		public LoginPage clickSignUp() {
			signupbtn.click();
			return new LoginPage(driver);
		}
		public String getCurrentURL() {
			
			return driver.getCurrentUrl();
		}
		public String getErrorMsg() {
			return errormsg.getText();
		}
		
		public boolean checkUrl(String property) {
			return rf.checkurl(property);
		}
		
		public boolean isPresent(WebElement element) {
			return rf.isPresent(element);
		}
	    
	}



package com.ust.demoblaze.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseUI.ReusableFunctions;

public class AddToCart {
	WebDriver driver;
	ReusableFunctions rf;
	 
	public AddToCart(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		}
	
	@FindBy(xpath= "phones")
	public WebElement phones;
	
	@FindBy(xpath = "//a[normalize-space()='Samsung galaxy s6']")
	public WebElement samsung;
	
	@FindBy(css = ".btn.btn-success.btn-lg")
	public WebElement addtocart;
	

	@FindBy(xpath = "//a[@id='cartur']")
	public WebElement cart;
	

	@FindBy(xpath = "//button[normalize-space()='Place Order']")
	public WebElement placeorder;
	
	@FindBy(id = "name")
	public WebElement name;
	
	@FindBy(id = "country")
	public WebElement country;
	
	@FindBy(id = "city")
	public WebElement city;
	
	@FindBy(id = "card")
	public WebElement card;
	
	@FindBy(id = "month")
	public WebElement month;
	
	@FindBy(id = "year")
	public WebElement year;//div[10]/div[7]/div/button
	
	@FindBy(xpath = "//div[10]/div[7]/div/button")
	public WebElement ok;
	


	
	
	
	public String getCurrentURL() {
		return driver.getCurrentUrl();
	}
}



package com.ust.demoblaze.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseUI.ReusableFunctions;

public class LoginPage {

		WebDriver driver;
		AddToCart ac;
		ReusableFunctions rf;


	public LoginPage(WebDriver driver) {
	this.driver = driver;
	PageFactory.initElements(driver, this);
	}


	@FindBy(xpath= "//a[@id='login2']")
	public WebElement login;
	
	@FindBy(id = "loginusername")
	public WebElement username;

	@FindBy(id = "loginpassword")
	public WebElement password;

	@FindBy(xpath="//*[@id=\"logInModal\"]/div/div/div[3]/button[2]")
	public WebElement Loginbtn;

	@FindBy(id="signInResultMessage")
	public WebElement errormsg;

	
	
	public void Login() {
		login.click();
		
	}
	public void enterusername(String utext) {
		username.sendKeys(utext);
	}
	public void enterpassword(String ptext) {
		password.sendKeys(ptext);
	}
	
	public AddToCart clicklogin() {
		Loginbtn.click();
		return new AddToCart(driver);
	}
	public String getCurrentURL() {
		
		return driver.getCurrentUrl();
	}
	public String getErrorMsg() {
		return errormsg.getText();
	}
	
	
}







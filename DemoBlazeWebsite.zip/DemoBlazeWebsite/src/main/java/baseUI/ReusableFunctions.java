package baseUI;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ReusableFunctions {
	public WebDriver driver;
	 
	public ReusableFunctions(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
 
	}
	public void clickElement(WebElement element) {
		element.click();
	}
	public boolean containsText(String txt,WebElement element) {
		return element.getText().contains(txt);
	}
	public boolean checkurl(String url) {
		if ((driver.getCurrentUrl()).equals(url)) {
			return true;
		} else {
			return false;
		}
	}
	public boolean isPresent(WebElement element) {
		if (element.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}
	public void insertText(String text, WebElement element) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		element.clear();
		element.sendKeys(text);
	}
  public void waits() {
	  try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
  
  public void selectdropdown(WebElement element,String txt) {
     Select Obj=new Select(element);
     Obj.selectByVisibleText(txt);
     
  }
}



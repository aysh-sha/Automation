package baseUI;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.ust.demoblaze.utils.ObjectReader;

public class SetUp {
	public static WebDriver driver;
	public static Properties prop;
	public static String browser_choice;
	public  SetUp() {
	    prop=ObjectReader.initProperties();
	}
	    public static WebDriver invokeBrowser() {
	    	browser_choice=prop.getProperty("driver");
	    	try {
	    		if(browser_choice.equalsIgnoreCase("chrome")) {
	    			driver=ObjectReader.getchromeDriver();
	    		}
	    		else if(browser_choice.equalsIgnoreCase("msedge")) {
	    			driver=ObjectReader.getEdgeDriver();
	    		}
	    		else {
	    			throw new Exception("Invalid  browser name provided in property file");
	    		}
	    	}
	    		catch(Exception e) {
	    			e.getMessage();
	    		}
	    		return driver;
	    }
 
	    public static void takeScreenshot(String filepath) {

			TakesScreenshot takeScreenShot = (TakesScreenshot) driver;
			File srcFile = takeScreenShot.getScreenshotAs(OutputType.FILE);
			File destFile = new File(filepath);
			try {
				FileUtils.copyFile(srcFile, destFile);
			}catch (IOException e) {
				e.printStackTrace();
			}
	    }
	    //Get the timestamp in format: yyyy.MM.dd.HH.mm.ss
	    
	    public static String getTimeStamp() {
	    	return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	    }
		

	    
	    
}




package CucumberBBDSample;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(
		features = {"C:\\Users\\271559\\Desktop\\Java\\com.ust.CucumberBBDSample"},
		glue = {"CucumberBBDSample"}
		//dryRun = true
		)
public class CucumberRunner extends AbstractTestNGCucumberTests{
}
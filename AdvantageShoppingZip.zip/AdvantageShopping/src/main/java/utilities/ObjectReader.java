package utilities;

import java.io.FileInputStream;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class ObjectReader {
	public static WebDriver driver;
	private static Properties prop;
	
	
	public static Properties initProperties() {
		if(prop == null)
			prop = new Properties();
		try {
			  FileInputStream file =  new FileInputStream(System.getProperty("user.dir") +"\\src\\test\\resources\\ObjectRepository\\object.properties");
			  prop.load(file);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return prop;
		
	}
	
	
	public static WebDriver getchromeDriver() {
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--disable-infobars");
		co.addArguments("--disable-notifactions");
		co.addArguments("--disable-maximixed");
		co.addArguments("force-drive-scale-factor=0.9");
		driver= new ChromeDriver(co);
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		return driver;
	}
	
	public static WebDriver getEdgeDriver() {
		EdgeOptions eo = new EdgeOptions();
		eo.addArguments("--disable-infobars");
		eo.addArguments("--disable-notifactions");
		eo.addArguments("--disable-maximixed");
		eo.addArguments("force-drive-scale-factor=0.9");
		driver= new EdgeDriver(eo);
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		return driver;
	}
	
	
	

}





package cucumberTest;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features = {"C:\\Users\\271559\\Desktop\\Java\\AdvantageShopping"},
		glue = {"cucumberTest"},
		
		  plugin = { "pretty",
		  "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
		  "timeline:test-output-thread", "html:Reports/cucumber-reports/index.html"}
		 
		)
//publish = true
		//plugin = {"me.jvt.cucumber.report.PrettyReports:Reports"}
		//dryRun = true
		
public class CucumberRunner extends AbstractTestNGCucumberTests{
}

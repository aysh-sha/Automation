package cucumberTest;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;

import baseUI.SetUp;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.LoginPage;
import pages.ProductsPage;

public class LoginTest extends SetUp {
	
	LoginPage lp;
	ProductsPage pp;
	
	@Before
	public void setup() throws IOException {
		driver = SetUp.invokeBrowser();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	@After
	public void teardown() throws InterruptedException {
		Thread.sleep(3000);
		driver.close();
	}
	
	@Given("the user in the AdvantageShopping Login page")
	public void the_user_in_the_advantage_shopping_login_page() {
		driver.get(prop.getProperty("baseurl"));
		lp = new LoginPage(driver);
		
	}
	@When("the valid username is entered")
	public void the_valid_username_is_entered() {
		lp = new LoginPage(driver);
		lp.enterusername("mahima");	
		}
	@And("the valid password is entered")
	public void the_valid_password_is_entered() {
		lp = new LoginPage(driver);
		lp.enterusername("Mahi@123");	
		
	}
	
	@And("the login button is clicked")
	public void the_login_button_is_clicked() {
		pp = lp.clicklogin();
		
	}
	@Then("the products page should be displayed")
	public void the_products_page_should_be_displayed() {
		String actURL = pp.getCurrentURL();
		  assertTrue(actURL.contains(""));
	}

}

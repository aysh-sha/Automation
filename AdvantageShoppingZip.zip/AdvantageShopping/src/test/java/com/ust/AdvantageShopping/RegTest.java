package com.ust.AdvantageShopping;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import baseUI.ReusableFunctions;
import baseUI.SetUp;
import pages.UserReg;
import utilities.ExtentReportListener;

@Listeners(ExtentReportListener.class)
public class RegTest extends SetUp {
	UserReg ur;
	ReusableFunctions rf;
  
  @Test(priority = 0)
	public void loadLoginPage() {
		driver.get(prop.getProperty("baseurl"));
		ur = new UserReg(driver);
		assertTrue(ur.checkUrl(prop.getProperty("baseurl")), "Failed to load base url");
	}

	@Test(priority = 1)
	public void clickRegister() throws InterruptedException {
		ur.click(ur.userregistration);
		ur.click(ur.newacc);
		ur.click(ur.registerbtn);
		wait();
		assertTrue(ur.isPresent(ur.registerbtn), "Login with null data case failed");
		
	}
	@Test(priority = 2)
	public void enterCredentials() throws InterruptedException {
		ur.click(ur.userregistration);
		ur.click(ur.newacc);
		ur.click(ur.registerbtn);
		ur.enterText(ur.username, prop.getProperty("username"));
		ur.enterText(ur.email, prop.getProperty("email"));
		ur.enterText(ur.password, prop.getProperty("password"));
		ur.enterText(ur.confrimpassword, prop.getProperty("confirm"));
		ur.enterText(ur.firstname, prop.getProperty("firstname"));
		ur.enterText(ur.lastname, prop.getProperty("lastname"));
		ur.enterText(ur.phonenumber, prop.getProperty("phonenumber"));
		rf.selectdropdown(ur.country,prop.getProperty("country"));
		ur.enterText(ur.city, prop.getProperty("city"));
		ur.enterText(ur.address, prop.getProperty("address"));
		ur.enterText(ur.state, prop.getProperty("state"));
		ur.enterText(ur.postal, prop.getProperty("postal"));
		
		ur.click(ur.checkbox);
		ur.click(ur.registerbtn);
		
		assertTrue(ur.checkUrl(prop.getProperty("register")),"Failed to login");

		Thread.sleep(2000);
		
}
}
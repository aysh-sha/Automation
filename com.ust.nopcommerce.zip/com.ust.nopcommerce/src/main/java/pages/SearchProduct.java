package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import utils.ExcelReader;

public class SearchProduct {
	WebDriver driver;
	ExcelReader read;


	public SearchProduct(WebDriver driver)
	{
		this.driver=driver;
	}
	


public void Search()
{  //Select electonics
	driver.findElement(By.linkText("Electronics")).click();
	//
	driver.findElement(By.linkText("//ul[@class='top-menu notmobile']//a[normalize-space()='Camera & photo']")).click();
	//Click on Camera
	driver.findElement(By.xpath("//div[1]/div/div[1]/div/div/a/img")).click();
	driver.findElement(By.name("products-orderby")).click();
	Select dropdown = new Select(driver. findElement(By.xpath("products-orderby"))); 
    dropdown.selectByVisibleText("Price: Low to High");
	driver.findElement(By.xpath("//div[1]/div/div[1]/div/div/a/img")).click();
	driver.findElement(By.xpath("//div[1]/div/div[1]/div/div/a/img")).click();
}
}
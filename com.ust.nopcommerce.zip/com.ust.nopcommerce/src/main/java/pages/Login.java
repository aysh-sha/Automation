package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utils.ExcelReader;

public class Login {
	
	WebDriver driver;
	ExcelReader read;


	public Login(WebDriver driver)
	{
		this.driver=driver;
	}
	


		public void LoginPage()
		{
		    try {
				read = new ExcelReader(System.getProperty("user.dir")+"\\DataSheet\\Login.xlsx");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			int rowCount = read.getRowCount(0);
			//Click on login
			driver.findElement(By.linkText("Log in")).click();
			//Clear the email
			driver.findElement(By.id("Email")).clear();
			driver.findElement(By.id("Email")).sendKeys(read.getData(0,0,0));// email read from excel 
			driver.findElement(By.name("Password")).clear();
			driver.findElement(By.name("Password")).sendKeys(read.getData(0,0,1));//password read from excel
			driver.findElement(By.xpath("//button[normalize-space()='Log in']")).click();
		}
}



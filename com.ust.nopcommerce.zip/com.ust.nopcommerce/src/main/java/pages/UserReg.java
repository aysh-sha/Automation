package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class UserReg {
	WebDriver driver;


public UserReg(WebDriver driver)
{
	this.driver=driver;
}
By Register = By.linkText("Register");
By Gender= By.id("gender-female");
By FirstName = By.id("FirstName");
By LastName= By.id("LastName");
By Day= By.xpath("//div[2]/div[4]/div/select[1]");
By Month= By.xpath("//div[2]/div[4]/div/select[2]");
By Year= By.xpath("//div[2]/div[4]/div/select[3]");
By Email= By.name("Email");
By Password= By.id("Password");
By confPassword= By.id("ConfirmPassword");
By Registerbttn = By.id("register-button");


public void Register()
{
	//Click on register
	driver.findElement(Register).click();
	driver.findElement(Gender).click();
	driver.findElement(FirstName).sendKeys("Aysha");
	driver.findElement(LastName).sendKeys("S");
	
	Select Day1 = new Select(driver.findElement(Day)); 
    Day1.selectByVisibleText("31");
    Select Month1 = new Select(driver. findElement(Month)); 
    Month1.selectByVisibleText("December");
    Select Year1 = new Select(driver. findElement(Year)); 
    Year1.selectByVisibleText("2000");
    
    driver.findElement(Email).sendKeys("aysha@gmail.com");
	driver.findElement(Password).sendKeys("123aysha");
	driver.findElement(confPassword).sendKeys("123aysha");

	
	driver.findElement(Registerbttn).click();
}
}
package objectRepositoryReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ObjectReader {
	Properties p;
	public ObjectReader() throws IOException {
		String objPath = System.getProperty("user.dir")+"\\ObjectRepository\\object.properties";
		FileReader reader = new FileReader(objPath);
		p = new Properties();
		p.load(reader);
		//System.out.println(p.getProperty("BaseUrl"));
	}
	public String getBaseUrl() {
		return p.getProperty("BaseUrl");
	}
 
}	



package com.ust.nopcommerce;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Browser.BrowserImplementation;
import objectRepositoryReader.ObjectReader;
import pages.Login;
import pages.SearchProduct;
import pages.UserReg;
import utils.Screenshot;

public class nopcommTest {
	WebDriver driver;
	UserReg ur;
	BrowserImplementation bi;
	ObjectReader or;
	Login lp;
	SearchProduct sp;
	
	 
		ExtentReports extent;
		ExtentSparkReporter spark;
		ExtentTest test;
	
  @Test(priority=1)
	
	  public void VerifyRegistration() { 
	  ur = new UserReg(driver); 
	  ur.Register();
	  }
	 
  @Test(priority=2)
	  public void VerifyLogin() { 
		  lp = new Login(driver); 
		  lp.LoginPage();
		  test = extent.createTest("Validate Title");
			 
		  try {
			  
			  String exp="My account";
			  String actual = driver.findElement(By.linkText("My account")).getText();
			  assertEquals(actual,exp);
			  test.log(Status.PASS, "Verified Title, status-PASS");
			  test.assignAuthor("Aysha").assignDevice("Windows").assignDevice("Chrome");
		  }
		  
		  catch (AssertionError e) {
			  test.log(Status.FAIL, "Verified Title, status-FAIL");
			  test.assignAuthor("Aysha").assignDevice("Windows").assignDevice("Chrome");
		  }
	  }
		  
	
  @Test(priority=3)
	
  public void VerifySearch() { 
  sp = new SearchProduct(driver); 
  sp.Search();
  }
	 
  

  @BeforeClass
  public void beforeClass() throws IOException {
	  bi = new BrowserImplementation();
		driver = bi.LaunchChrome();
		
		or = new ObjectReader();
		driver.get(or.getBaseUrl());
		
  }

  @AfterMethod
  public void afterMethod(ITestResult result) {
	  
		    try
		 {
		    if(result.getStatus() == ITestResult.SUCCESS)
		    {
	
		        System.out.println("passed");
		    }
	
		    else if(result.getStatus() == ITestResult.FAILURE)
		    {
		    	Screenshot ss= new Screenshot();
		    	Screenshot.takeScreenshot(driver);
		         
		        System.out.println("Failed");
	
		    }
		 
		     else if(result.getStatus() == ITestResult.SKIP ){
		      System.out.println("Skiped");
	
		    }
		}
		   catch(Exception e)
		   {
		     e.printStackTrace();
		   }
	
		}

  
@AfterClass
public void afterClass() {
	  driver.quit();
}
}

package pages;

import java.awt.Menu;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
WebDriver driver;
ProductsPage pp;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(id= "menuUser")
	private WebElement menuclick;
	
	@FindBy(name = "username")
	private WebElement username;
	
	@FindBy(name = "password")
	private WebElement password;
	
	@FindBy(id="sign_in_btn")
	private WebElement Loginbtn;
	
	@FindBy(id="signInResultMessage")
	private WebElement errormsg;
	
	@FindBy(xpath="//span[@class='hi-user containMiniTitle ng-binding']")
	private WebElement usercheck;
	
	
	
	public void menu() {
		menuclick.click();
		
	}
	
	public void enterusername(String utext) {
		username.sendKeys(utext);
	}
	public void enterpassword(String ptext) {
		password.sendKeys(ptext);
	}
	
	public ProductsPage clicklogin() {
		Loginbtn.click();
		return new ProductsPage(driver);
	}
	public String getCurrentURL() {
		
		return driver.getCurrentUrl();
	}
	public String getErrorMsg() {
		return errormsg.getText();
	}
	
	public String namecheck() {
		return usercheck.getText();
	}
    
}


